import requests
import json
import time

last_hash = None
ltc_addy = 'LQpeTdyx9MyCxNfKV3ca6tSxS1mQxkr7dJ'
webhook_url = "https://discord.com/api/webhooks/1288743731368955934/mj-tzbY3F2CRzTY7gtIMFIPfcwLX4oNxNa0KBHLFqiy6oOMEX_PWX6eTxFa8yHY1EDfo"

def check_transactions():
    global last_hash
    response = requests.get(f'https://api.blockcypher.com/v1/ltc/main/addrs/{ltc_addy}/full').json()

    if 'txs' in response:
        latest_transaction = response['txs'][0]
        latest_hash = latest_transaction['hash']
        if latest_hash != last_hash:
            total_received = sum(output['value'] / 1e8 for output in latest_transaction['outputs'] if 'addresses' in output and ltc_addy in output['addresses'])
            ltc_to_usd_rate = requests.get('https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd').json()['litecoin']['usd']
            total_received_usd = total_received * ltc_to_usd_rate
            if total_received > 0:
                send_transaction_notification(latest_hash, total_received_usd)
            last_hash = latest_hash

def send_transaction_notification(hash: str, amount: float):
    ltc_to_usd_rate = requests.get('https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd').json()['litecoin']['usd']
    transaction = requests.get(f'https://api.blockcypher.com/v1/ltc/main/txs/{hash}').json()
    if 'inputs' in transaction:
        input_address = transaction['inputs'][0]['addresses'][0]

    embed = {
        "title": "New LTC Transaction",
        "color": 0,
        "fields": [
            {"name": "Hash", "value": f"[{hash}](https://live.blockcypher.com/ltc/tx/{hash})", "inline": False},
            {"name": "Amount", "value": f"${amount:.2f}", "inline": False},
            {"name": "Sent From", "value": input_address, "inline": False},
            {"name": "LTC Price", "value": f"${ltc_to_usd_rate:.2f}", "inline": False}
        ]
    }

    data = {
        "content": "New transaction detected!",
        "embeds": [embed]
    }

    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(webhook_url, data=json.dumps(data), headers=headers)
    if response.status_code != 204:
        print(f"Failed to send webhook: {response.status_code}")

while True:
    check_transactions()
    time.sleep(60)  
